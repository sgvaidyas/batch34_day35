﻿
$(document).ready(function () {
    $('#satishprofile').hide();
    $('#samanathaprofile').hide();
    $('#pf1').click(function () {
        $('#samanathaprofile').hide();
        $('#satishprofile').show();
    });

    $('#pf2').click(function () {
        $('#satishprofile').hide();
        $('#samanathaprofile').show();
    });
});